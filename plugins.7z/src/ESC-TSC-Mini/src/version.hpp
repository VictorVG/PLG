#include "farversion.hpp"

#define FULLMAKEPRODUCTVERSION1(major, minor, sub, build) #major "." #minor "." #sub "." #build
#define MAKEPRODUCTVERSION1(major, minor, sub, build) FULLMAKEPRODUCTVERSION1(major, minor, sub, build)
#define PLUGIN_MAJOR 1
#define PLUGIN_MINOR 5
#define PLUGIN_BUILD 1
#define PLUGIN_DESC L"ESC's Temporary Settings Changer - Minimalistic"
#define PLUGIN_NAME L"ESC-TSC-Mini"
#define PLUGIN_FILENAME L"esc-tsc-mini.dll"
#define PLUGIN_AUTHOR L"Alex Yaroslavsky"

#define PLUGIN_VERSION MAKEFARVERSION(PLUGIN_MAJOR,PLUGIN_MAJOR,PLUGIN_BUILD,FARMANAGERVERSION_BUILD,VS_RELEASE)
