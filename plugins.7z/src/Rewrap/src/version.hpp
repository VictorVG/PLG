#include "farversion.hpp"

#define FULLMAKEPRODUCTVERSION1(major, minor, sub, build) #major "." #minor "." #sub "." #build
#define MAKEPRODUCTVERSION1(major, minor, sub, build) FULLMAKEPRODUCTVERSION1(major, minor, sub, build)

#define PLUGIN_MAJOR 2
#define PLUGIN_MINOR 3
#define PLUGIN_BUILD 1
#define PLUGIN_DESC L"Reformat paragraph based on ESC plugin settings"
#define PLUGIN_NAME L"Rewrap"
#define PLUGIN_FILENAME L"rewrap.dll"
#define PLUGIN_AUTHOR L"Stanislav V. Mekhanoshin & Alex Yaroslavsky"
#define PLUGIN_VERSION MAKEFARVERSION(PLUGIN_MAJOR,PLUGIN_MAJOR,PLUGIN_BUILD,FARMANAGERVERSION_BUILD,VS_RELEASE)
