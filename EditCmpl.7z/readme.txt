EditCmpl (Word Completion) v4.0.0.0.3 Alpha for Far3 b4040+ (x86 and x86-64)

* Git-d7027514a: Mark colors as opaque for Far 3.0.5821+ (Fix by Alex Alabuzhev)
* Rebuild use GCC 10.2