﻿Macro {
id="fd289a0e-bcbb-49a4-bd2b-3ce98ffd89b9";
area="Shell Info QView Tree";
key="Esc";
flags="EmptyCommandLine";
description="Включить/выключить панели.";
action = function()
  return Keys("CtrlO")
end;
}
