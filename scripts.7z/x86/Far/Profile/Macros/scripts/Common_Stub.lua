﻿-- This is stub for some potential data lost keys. Don't remove it! /VictorVG/
-- v1.0, Initial build
-- 27.11.2019 15:05:37 +0300

Macro{
  id="029AACF6-8B9E-4ED3-8218-4CD556FDB30A";
  area="Shell Tree";
  key="CtrlShiftX";
  description="CtrlShiftX stub";
  action=function() Keys("CtrlShiftC") end;
}