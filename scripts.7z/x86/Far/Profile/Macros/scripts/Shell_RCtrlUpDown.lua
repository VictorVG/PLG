﻿Macro {
id="49c9caff-9332-47ee-9470-c117e3f63b87";
area="Shell";
key="RCtrlUp";
description="Предыдущая команда (CtrlE).";
action=function()
 return Keys("CtrlE")
end;
}

Macro {
id="9656a05f-d2e6-4ae6-8ca4-5efd667120b5";
area="Shell";
key="RCtrlDown";
description="Следующая команда (CtrlX).";
action=function()
 return Keys("CtrlX")
end;
}
