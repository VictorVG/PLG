﻿Macro {
area="Shell"; key="RCtrlUp"; description="Предыдущая команда (CtrlE).";
action=function()
  Keys("CtrlE")
end;
}

Macro {
area="Shell"; key="RCtrlDown"; description="Следующая команда (CtrlX).";
action=function()
  Keys("CtrlX")
end;
}
