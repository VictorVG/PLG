﻿Macro {
area="Shell"; key="RCtrlUp"; description="Предыдущая команда (CtrlE).";
action=function()
 return Keys("CtrlE")
end;
}

Macro {
area="Shell"; key="RCtrlDown"; description="Следующая команда (CtrlX).";
action=function()
 return Keys("CtrlX")
end;
}
