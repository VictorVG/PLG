Macro {
  area="Shell"; key="Ctrl="; description="Same Folder"; action = function()
    panel.SetPanelDirectory(nil,0,panel.GetPanelDirectory(nil,1))
  end;
}