-- Сдвиг на один символ влево, курсор не переходит на предыдущую строку
-- Sat Jun 21 12:07:23 +0400 2014, VictorVG @ VikSoft.Ru, (c) 1996 - 2014
Macro{
      area="Editor"; key="AltLeft"; flags="NoSendKeysToPlugins";
      description="Stepping left shift to end of line";
      action=function() Keys "CtrlS" end;
     }
