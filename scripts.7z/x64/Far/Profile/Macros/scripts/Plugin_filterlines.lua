local FLID="0A2DEABF-6103-43DB-AA7A-BD1F7A23E0ED"
local FLMID="0A2DEABF-6103-43DB-AA7A-BD1F7A23E0ED"
Macro {
  description="FilterLines - increment string filter"; area="Editor"; key="LAltF"; action=function()
   Plugin.Menu(FLID,FLMID)
  end;
}