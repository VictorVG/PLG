Macro {
  area="Shell"; key="CtrlS"; flags=""; description="Use Ctrl-S for quick search like mc."; action = function()
Keys('Alt< ')
  end;
}