﻿Macro {
  area="Shell"; key="Del NumDel"; flags="EmptyCommandLine"; description="Use Del to remove files"; action = function()
Keys('F8')
  end;
}

Macro {
  area="Search"; key="Del NumDel"; flags="EnableOutput"; description="Use Del to remove files"; action = function()
Keys('F8')
  end;
}

Macro {
  area="Tree"; key="Del NumDel"; flags="EmptyCommandLine"; description="Use Del to remove files"; action = function()
Keys('F8')
  end;
}
