Macro {
  area="Search"; key="CtrlIns"; flags=""; description="CtrlIns в быстром поиске"; action = function()
Keys('Esc CtrlIns')
  end;
}

Macro {
  area="Search"; key="CtrlNum0"; flags=""; description="CtrlIns в быстром поиске"; action = function()
Keys('Esc CtrlIns')
  end;
}
