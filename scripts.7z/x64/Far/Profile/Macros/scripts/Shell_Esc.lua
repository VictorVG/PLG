﻿Macro {
area="Shell Info QView Tree"; key="Esc"; flags="EmptyCommandLine"; description="Включить/выключить панели.";
action = function()
  Keys("CtrlO")
end;
}
