--
-- Console Control
-- (c) Max Rusov
-- http://code.google.com/p/far-plugins
--
-- Макросы управлением консольным окном
-- Поместите файл в %FARPROFILE%\Macros\Srcipts
--
-- AltShift+Стрелки   - Изменение размера окна
-- Ctrl+КолесоМыши    - Изменение размера шрифта
-- CtrlAlt+КолесоМыши - Изменение прозрачности окна
-- Alt+F9             - Maximize/Restore
-- CtrlAlt+F9         - Включение/выключение большого буфера экрана (в режиме "/w")
-- CtrlAlt+Цифры      - Пресеты размеров
--

require "ConsoleControl"


function ShowHint(Mess)
  local FarHints = "CDF48DA0-0334-4169-8453-69048DD3B51C"
  if Mess then
    Plugin.Call(FarHints, "Info", Mess)
  else
    Plugin.Call(FarHints, "Hide")
  end
end


Macro { description="Console Control: Change Windows Size"; area="Common"; key="AltShiftUp AltShiftDown AltShiftLeft AltShiftRight";
  condition=function()
    return ConsoleControl.Installed()
  end;
  action=function()
    local S = akey(1):sub(9);
    local DX = S == "Right" and 1 or S == "Left" and -1 or 0
    local DY = S == "Down" and 1 or S == "Up" and -1 or 0
    local CX, CY = ConsoleControl.WindowSizeDelta(DX, DY)
    if CX and CY then
      ShowHint("Size: " .. CX .. " x " .. CY)
    end
  end;
}

Macro { description="Console Control: Change Font Size"; area="Common"; key="CtrlMsWheelUp CtrlMsWheelDown";
  condition=function()
    return ConsoleControl.Installed()
  end;
  action=function()
    local D = akey(1):sub(-2) == "Up" and 1 or -1
    local Size, Name = ConsoleControl.FontSizeDelta(D)
    if Size and Name then
      ShowHint("Font: " .. Name .. ", " .. Size)
    end
  end;
}

Macro { description="Console Control: Change Transparency"; area="Common"; key="CtrlAltMsWheelUp CtrlAltMsWheelDown";
  condition=function()
    return ConsoleControl.Installed()
  end;
  action=function()
    local D = akey(1):sub(-2) == "Up" and 1 or -1
    local Tarnsp = ConsoleControl.Transparency()
    Tarnsp = ConsoleControl.Transparency(Tarnsp + D * 5)
    if Tarnsp then
      ShowHint("Transparency: " .. Tarnsp)
    end
  end;
}

Macro { description="Console Control: Maximize/Restore"; area="Common"; key="AltF9";
  condition=function()
    return ConsoleControl.Installed()
  end;
  action=function()
    local Max = ConsoleControl.Maximize(-1)
    if Max then
--    ShowHint("Maximize: " .. (Max == 1 and "On" or "Off") )
      ShowHint()
    end
  end;
}


Macro { description="Console Control: Maximize/Restore console buffer"; area="Shell"; key="CtrlAltF9";
  condition=function()
    return ConsoleControl.Installed()
  end;
  action=function()
    local MaxY = 1000
    local CX, CY = ConsoleControl.BufferSize()
    if CX and CY then
--    ShowHint("Buffer: " .. CX .. " x " .. CY)
      if CY < MaxY  then
        ConsoleControl.BufferSize(0, MaxY)
      else
        ConsoleControl.BufferSize(-1, -1)
      end
      -- Устраняет глюки консоли
      Keys("CtrlY c l s Enter")
    end
  end;
}

Macro { description="Console Control: Topmost On/Off"; area="Shell"; key="CtrlAltPgUp";
  condition=function()
    return ConsoleControl.Installed()
  end;
  action=function()
    local Top = ConsoleControl.Topmost(-1)
    if Top then
      ConsoleControl.Transparency( Top == 1 and 50 or 0 )
      ShowHint("Topmost: " .. (Top == 1 and "On" or "Off"))
    end
  end;
}


-- Size presets

Macro { description="Window size 80x25"; area="Common"; key="CtrlAlt1 CtrlAlt0";
  action=function()
    ConsoleControl.WindowSize(80, 25)
  end;
}
Macro { description="Window size 80x50"; area="Common"; key="CtrlAlt2 CtrlAlt0";
  action=function()
    ConsoleControl.WindowSize(80, 50)
  end;
}
Macro { description="Window size 160x80"; area="Common"; key="CtrlAlt3 CtrlAlt0";
  action=function()
    ConsoleControl.WindowSize(160, 80)
  end;
}
