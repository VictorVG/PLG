Plug-in "AudioPlayer" for Far Manager 3.0
*****************************************

Simple audio player based on BASS library (http://www.un4seen.com/).

The following file formats are supported: 
  *.aac;*.ac3;*.aif;*.aiff;*.ape;*.fla;*.flac;*.it;*.kar;*.m4a;*.m4b;*.m4r;*.mac;*.mid;*.midi;
  *.mo3;*.mod;*.mp+;*.mp1;*.mp2;*.mp3;[*.mp4];*.mpc;*.mpp;*.mtm;*.oga;*.ogg;*.opus;*.rmi;*.s3m;
  *.spx;*.umx;*.wav;*.wma;*.wv;*.xm

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
Vladimir Surguchev (vladimir.surguchev@gmail.com)
              https://sourceforge.net/projects/farplugs/files/AudioPlayer/
