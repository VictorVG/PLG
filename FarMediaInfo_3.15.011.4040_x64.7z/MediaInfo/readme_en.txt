Plug-in "Media Info" for Far Manager 3.0
****************************************

Plugin allows you to view information about media files (codec,
bitrate, duration, EXIF etc.).

Based on libraries:
- MediaInfo (http://mediainfo.sourceforge.net);
- Exiv2 (http://www.exiv2.org);
- Standart GDI+ (http://www.microsoft.com).

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
               https://sourceforge.net/projects/farplugs/
