Drag'N'Drop plug-in contributors in alphabetical order
======================================================

* [Evgeny Grechnikov](https://github.com/grechnik)
  * Maintainer

* [Eugene Leskinen](https://github.com/karbazol)
  * Author and maintainer

* [Victor](https://github.com/VictorVG)
  * QA and distribution

