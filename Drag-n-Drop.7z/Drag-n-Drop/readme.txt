Drag & Drop v3.0.0.85 plug-in for Far 3.0 b4700 x86 and AMD64

Archive included only MSVC2017 multi-threads build.

Description:

This plug-in enables drag'n'drop operations between Far and other apps.

Minimal OS supported:

Windows XP SP3 32 or 64 bit Edition
Far 3.0 b4700 x86 or x64

Windows Vista or never OS recommended.

Installation:

Just make ./<FarDirPath>/Plugins/DragNDrop or use command like:

  cd /d  <FarDirPath>
  md "Plugins\DragNDrop" or "Plugins\dnd"

directory and unzip files in to this dir for:

  x86 (32's bit Far) only ./Drag-n-Drop/x86/*
  AMD64 (64's bit Far) only ./Drag-n-Drop/x64/*

then restart Far if then running.

Notes:

Always delete drgndrop_*.hook and holder_x86*.dnd if exist - this files not
used for this release and can be deleted.