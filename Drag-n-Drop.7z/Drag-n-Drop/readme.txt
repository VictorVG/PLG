Drag & Drop v3.0.0.84 plug-in for Far 3.0 b4700 x86 and AMD64

Archive included tow independent build - MSVC2015 and MSVC2017. Use then like.

Description:

This plug-in enables drag'n'drop operations between Far and other apps.

Minimal required:

MSVC2015 build:

Windows XP SP3 32 or 64 bit edition
Far 3.0 b4700 x86 or x64

MSVC2017 build:

Windows Vista 32 or 64 bit edition
Far 3.0 b4700 x86 or x64

Installation:

Just make ./<FarDirPath>/Plugins/DragNDrop or use command like:

  cd /d  <FarDirPath>
  md "Plugins\DragNDrop"

directory and unzip files in to this dir for:

  x86 (32's bit Far) only ./Drag-n-Drop/x86/*
  AMD64 (64's bit Far) only ./Drag-n-Drop/x64/*

then restart Far if then running.