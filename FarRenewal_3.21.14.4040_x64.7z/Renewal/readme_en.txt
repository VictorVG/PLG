Plug-in "Renewal" for Far Manager 3.0
*************************************

Autoupdate Far and external plug-ins.

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Anton Afanasyev (aasoft@gmail.com)
               https://bitbucket.org/aasoft/far-renewal

Vladimir Surguchev (2usen10@gmail.com)
               https://sourceforge.net/projects/farplugs/files/Renewal/
