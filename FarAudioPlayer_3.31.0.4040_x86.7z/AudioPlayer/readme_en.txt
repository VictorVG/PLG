Plug-in "AudioPlayer" for Far Manager 3.0
*****************************************

Simple audio player based on BASS library (http://www.un4seen.com/).

The following file formats are supported: 
  *.aiff,*.mp1,*.mp2,*.mp3,[*.mp4],*.ogg,*.wav,*.mo3,*.it,*.xm,*.s3m,*.mtm,
  *.mod,*.umx,*.m4a,*.flac,*.fla,*.oga,*.wma,*.wv,*.wvc,*.aac,*.m4b,*.ac3,
  *.ape,*.mac,*.mpc,*.mp,*.mpp,*.spx,*.midi,*.mid,*rmi,*.kar

Install:
  Unpack the archive to the Far plugins directory (...Far\Plugins).

Warning:
  This plugin is provided "as is". The author is not responsible for the
  consequences of use of this software.

Artem Senichev (artemsen@gmail.com)
               https://sourceforge.net/projects/farplugs/
