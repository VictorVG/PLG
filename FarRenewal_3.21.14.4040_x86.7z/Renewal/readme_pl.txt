Wtyczka "Renewal" dla Far Manager 3.0
*************************************

Automatyczna aktualizcja Far i wtyczek zewn�trznych.

Instalacja:
  Rozpakowa� archiwum do folderu wtyczek w Far (...Far\Plugins).

Uwaga:
  Wtyczka jest udost�pniana "jak jest" (bez gwarancji). Autor nie odpowiada za konsekwencje
  wynikaj�ce z u�ywania tego programu.

Anton Afanasyev (aasoft@gmail.com)
               https://bitbucket.org/aasoft/far-renewal

Vladimir Surguchev (2usen10@gmail.com)
               https://sourceforge.net/projects/farplugs/files/Renewal/
