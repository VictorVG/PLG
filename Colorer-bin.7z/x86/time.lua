﻿CommandLine {
  description = "Time";
  prefixes = "time";
  action = function(prefix,text)
    local windir = win.GetCurrentDir()
    local dir = panel.GetPanelDirectory(nil,1)
    if dir then win.SetCurrentDir(dir.Name) end

    panel.GetUserScreen()
    local t1 = Far.UpTime
    win.system(text)
    t1 = (Far.UpTime-t1)/1000
    panel.SetUserScreen()

    win.SetCurrentDir(windir)
    far.Message(("%f sec."):format(t1), "Time")
  end;
}