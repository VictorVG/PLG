Wtyczka "ImageView" dla Far Manager 3.0
***************************************

Przegl�darka grafik bazuje na bibliotece FreeImage (http://freeimage.sourceforge.net).

Instalacja:
  Rozpakowa� archiwum do folderu wtyczek w Far (...Far\Plugins).

Uwaga:
  Wtyczka jest udost�pniana "jak jest" (bez gwarancji). Autor nie odpowiada
  za konsekwencje wynikaj�ce z u�ywania tego programu.

Artem Senichev (artemsen@gmail.com)
               https://sourceforge.net/projects/farplugs/
